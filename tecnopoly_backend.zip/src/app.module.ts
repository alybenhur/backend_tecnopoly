import { Module }       from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';

import { AppController } from './app.controller';
import { AppService }    from './app.service';

import { User }             from './entities/user.entity';
import { Grade }            from './entities/grade.entity';
import { Subject }          from './entities/subject.entity';
import { SubjectProfessor } from './entities/subject-professor.entity';
import { Question }         from './entities/question.entity';
import { AnswerOption }     from './entities/answer-option.entity';

import { AuthModule }      from './auth/auth.module';
import { UsersModule }     from './users/users.module';
import { GradesModule }    from './grades/grades.module';
import { SubjectsModule }  from './subjects/subjects.module';
import { QuestionsModule } from './questions/questions.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' }),

    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject:  [ConfigService],
      useFactory: (config: ConfigService) => ({
        type:        'mysql',
        host:        config.get<string>('DB_HOST',     'localhost'),
        port:        config.get<number>('DB_PORT',     3306),
        username:    config.get<string>('DB_USER',     'root'),
        password:    config.get<string>('DB_PASSWORD', 'root'),
        database:    config.get<string>('DB_NAME',     'tecnopoly'),
        entities:    [User, Grade, Subject, SubjectProfessor, Question, AnswerOption],
        synchronize: true,   // crea/actualiza tablas automáticamente (solo desarrollo)
        charset:     'utf8mb4',
        timezone:    'Z',
      }),
    }),

    AuthModule,
    UsersModule,
    GradesModule,
    SubjectsModule,
    QuestionsModule,
  ],
  controllers: [AppController],
  providers:   [AppService],
})
export class AppModule {}
