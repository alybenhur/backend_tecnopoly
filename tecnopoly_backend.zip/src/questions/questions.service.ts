import {
  Injectable, NotFoundException,
  BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository }       from 'typeorm';
import { Question, QuestionLevelEnum } from '../entities/question.entity';
import { AnswerOption }     from '../entities/answer-option.entity';
import { CreateQuestionDto } from './dto/create-question.dto';
import { UpdateQuestionDto } from './dto/update-question.dto';
import { QuestionLevel }    from '../common/enums/question-level.enum';
import { Role }             from '../common/enums/role.enum';

@Injectable()
export class QuestionsService {
  constructor(
    @InjectRepository(Question)
    private questionRepo: Repository<Question>,
    @InjectRepository(AnswerOption)
    private answerRepo: Repository<AnswerOption>,
  ) {}

  private async verifyQuestion(id: string) {
    const q = await this.questionRepo.findOne({ where: { id } });
    if (!q) throw new NotFoundException(`Pregunta con id ${id} no encontrada`);
    return q;
  }

  async create(subjectId: string, dto: CreateQuestionDto, professorId: string) {
    const { answer_options, ...qData } = dto;

    if (dto.correct_answer_index >= answer_options.length)
      throw new BadRequestException(
        `correct_answer_index (${dto.correct_answer_index}) excede el número de opciones (${answer_options.length})`,
      );

    const question = this.questionRepo.create({
      ...qData,
      subject_id:  subjectId,
      created_by:  professorId,
      level:       qData.level as unknown as QuestionLevelEnum,
      answer_options: answer_options.map(o =>
        this.answerRepo.create({ option_text: o.option_text, order_index: o.order_index }),
      ),
    });

    const saved = await this.questionRepo.save(question);
    return this.findOne(saved.id);
  }

  async findAllBySubject(subjectId: string, level?: QuestionLevel) {
    const qb = this.questionRepo
      .createQueryBuilder('q')
      .leftJoinAndSelect('q.answer_options', 'ao')
      .where('q.subject_id = :subjectId', { subjectId })
      .orderBy('q.created_at', 'DESC')
      .addOrderBy('ao.order_index', 'ASC');

    if (level) qb.andWhere('q.level = :level', { level });

    return qb.getMany();
  }

  async findOne(id: string) {
    const q = await this.questionRepo
      .createQueryBuilder('q')
      .leftJoinAndSelect('q.answer_options', 'ao')
      .where('q.id = :id', { id })
      .orderBy('ao.order_index', 'ASC')
      .getOne();

    if (!q) throw new NotFoundException(`Pregunta con id ${id} no encontrada`);
    return q;
  }

  async update(id: string, dto: UpdateQuestionDto, user: { id: string; role: string }) {
    const question = await this.verifyQuestion(id);

    if (user.role !== Role.ADMIN && question.created_by !== user.id)
      throw new ForbiddenException('Solo puedes editar las preguntas que tú creaste');

    const { answer_options, ...qData } = dto;

    if (answer_options && dto.correct_answer_index !== undefined &&
        dto.correct_answer_index >= answer_options.length)
      throw new BadRequestException(
        `correct_answer_index (${dto.correct_answer_index}) excede el número de opciones (${answer_options.length})`,
      );

    if (Object.keys(qData).length > 0)
      await this.questionRepo.update(id, qData as any);

    if (answer_options && answer_options.length > 0) {
      await this.answerRepo.delete({ question_id: id });
      const opts = answer_options.map(o =>
        this.answerRepo.create({ question_id: id, option_text: o.option_text, order_index: o.order_index }),
      );
      await this.answerRepo.save(opts);
    }

    return this.findOne(id);
  }

  async remove(id: string, user: { id: string; role: string }) {
    const question = await this.verifyQuestion(id);

    if (user.role !== Role.ADMIN && question.created_by !== user.id)
      throw new ForbiddenException('Solo puedes eliminar las preguntas que tú creaste');

    await this.questionRepo.delete(id);
    return { message: `Pregunta con id ${id} eliminada correctamente` };
  }
}
