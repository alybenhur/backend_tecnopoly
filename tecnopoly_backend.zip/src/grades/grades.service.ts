import {
  Injectable, NotFoundException,
  ConflictException, InternalServerErrorException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository }       from 'typeorm';
import { Grade }            from '../entities/grade.entity';
import { Subject }          from '../entities/subject.entity';
import { CreateGradeDto }   from './dto/create-grade.dto';
import { UpdateGradeDto }   from './dto/update-grade.dto';

@Injectable()
export class GradesService {
  constructor(
    @InjectRepository(Grade)
    private gradeRepo: Repository<Grade>,
    @InjectRepository(Subject)
    private subjectRepo: Repository<Subject>,
  ) {}

  async create(dto: CreateGradeDto, adminId: string) {
    const existing = await this.gradeRepo.findOne({ where: { name: dto.name } });
    if (existing) throw new ConflictException(`Ya existe un grado con el nombre "${dto.name}"`);

    const grade = this.gradeRepo.create({ ...dto, created_by: adminId });
    try { return await this.gradeRepo.save(grade); }
    catch (e) { throw new InternalServerErrorException(e.message); }
  }

  async findAll() {
    return this.gradeRepo.find({
      relations: ['subjects'],
      order: { name: 'ASC' },
    });
  }

  async findOne(id: string) {
    const grade = await this.gradeRepo.findOne({
      where: { id },
      relations: ['subjects', 'subjects.subject_professors', 'subjects.subject_professors.professor'],
    });
    if (!grade) throw new NotFoundException(`Grado con id "${id}" no encontrado`);
    return grade;
  }

  async findSubjectsByGrade(gradeId: string) {
    await this.findOne(gradeId);
    return this.subjectRepo.find({
      where: { grade_id: gradeId },
      relations: ['subject_professors', 'subject_professors.professor'],
      order: { name: 'ASC' },
    });
  }

  async update(id: string, dto: UpdateGradeDto) {
    await this.findOne(id);
    if (dto.name) {
      const dup = await this.gradeRepo.findOne({ where: { name: dto.name } });
      if (dup && dup.id !== id)
        throw new ConflictException(`Ya existe un grado con el nombre "${dto.name}"`);
    }
    await this.gradeRepo.update(id, dto);
    return this.gradeRepo.findOne({ where: { id } });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.gradeRepo.delete(id);
    return { message: 'Grado eliminado correctamente' };
  }
}
