import {
  Injectable, NotFoundException,
  ConflictException, BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository }       from 'typeorm';
import { Subject }          from '../entities/subject.entity';
import { SubjectProfessor } from '../entities/subject-professor.entity';
import { User, UserRole }   from '../entities/user.entity';
import { CreateSubjectDto } from './dto/create-subject.dto';
import { UpdateSubjectDto } from './dto/update-subject.dto';
import { AssignProfessorDto } from './dto/assign-professor.dto';

@Injectable()
export class SubjectsService {
  constructor(
    @InjectRepository(Subject)
    private subjectRepo: Repository<Subject>,
    @InjectRepository(SubjectProfessor)
    private spRepo: Repository<SubjectProfessor>,
    @InjectRepository(User)
    private userRepo: Repository<User>,
  ) {}

  private async verifySubject(id: string) {
    const s = await this.subjectRepo.findOne({ where: { id } });
    if (!s) throw new NotFoundException(`Asignatura con id ${id} no encontrada`);
    return s;
  }

  private async verifyProfessor(professorId: string) {
    const u = await this.userRepo.findOne({ where: { id: professorId } });
    if (!u) throw new NotFoundException(`Profesor con id ${professorId} no encontrado`);
    if (u.role !== UserRole.PROFESOR)
      throw new ForbiddenException(`El usuario ${professorId} no tiene rol de profesor`);
    return u;
  }

  async create(dto: CreateSubjectDto, adminId: string) {
    const dup = await this.subjectRepo
      .createQueryBuilder('s')
      .where('LOWER(s.name) = LOWER(:name)', { name: dto.name })
      .getOne();
    if (dup) throw new ConflictException(`Ya existe una asignatura con el nombre "${dto.name}"`);

    const subject = this.subjectRepo.create({ ...dto, created_by: adminId });
    const saved   = await this.subjectRepo.save(subject);
    return this.findOne(saved.id);
  }

  async findAll() {
    return this.subjectRepo.find({
      relations: ['grade', 'subject_professors', 'subject_professors.professor'],
      order: { created_at: 'DESC' },
    });
  }

  async findOne(id: string) {
    const s = await this.subjectRepo.findOne({
      where: { id },
      relations: ['grade', 'subject_professors', 'subject_professors.professor'],
    });
    if (!s) throw new NotFoundException(`Asignatura con id ${id} no encontrada`);
    return s;
  }

  async update(id: string, dto: UpdateSubjectDto) {
    await this.verifySubject(id);
    if (dto.name) {
      const dup = await this.subjectRepo
        .createQueryBuilder('s')
        .where('LOWER(s.name) = LOWER(:name) AND s.id != :id', { name: dto.name, id })
        .getOne();
      if (dup) throw new ConflictException(`Ya existe una asignatura con el nombre "${dto.name}"`);
    }
    await this.subjectRepo.update(id, dto);
    return this.findOne(id);
  }

  async remove(id: string) {
    await this.verifySubject(id);
    await this.subjectRepo.delete(id);
    return { message: `Asignatura con id ${id} eliminada correctamente` };
  }

  async assignProfessor(subjectId: string, dto: AssignProfessorDto) {
    await this.verifySubject(subjectId);
    await this.verifyProfessor(dto.professor_id);
    const already = await this.spRepo.findOne({ where: { subject_id: subjectId, professor_id: dto.professor_id } });
    if (already) throw new ConflictException('El profesor ya está asignado a esta asignatura');
    const sp = this.spRepo.create({ subject_id: subjectId, professor_id: dto.professor_id });
    return this.spRepo.save(sp);
  }

  async removeProfessor(subjectId: string, professorId: string) {
    const sp = await this.spRepo.findOne({ where: { subject_id: subjectId, professor_id: professorId } });
    if (!sp) throw new NotFoundException('El profesor no está asignado a esta asignatura');
    await this.spRepo.delete({ subject_id: subjectId, professor_id: professorId });
    return { message: 'Profesor desasignado correctamente' };
  }

  async getProfessors(subjectId: string) {
    await this.verifySubject(subjectId);
    return this.spRepo.find({ where: { subject_id: subjectId }, relations: ['professor'] });
  }

  async isProfessorAssigned(subjectId: string, professorId: string): Promise<boolean> {
    const sp = await this.spRepo.findOne({ where: { subject_id: subjectId, professor_id: professorId } });
    return !!sp;
  }
}
