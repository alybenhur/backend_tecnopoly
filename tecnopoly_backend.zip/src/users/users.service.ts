import {
  Injectable, ConflictException,
  NotFoundException, BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository }       from 'typeorm';
import * as bcrypt          from 'bcrypt';
import { User, UserRole }   from '../entities/user.entity';
import { CreateUserDto }    from './dto/create-user.dto';
import { UpdateUserDto }    from './dto/update-user.dto';
import { Role }             from '../common/enums/role.enum';

const SALT_ROUNDS = 10;

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private userRepo: Repository<User>,
  ) {}

  async create(dto: CreateUserDto) {
    const existing = await this.userRepo.findOne({ where: { email: dto.email } });
    if (existing) throw new ConflictException(`El email ${dto.email} ya está registrado`);

    const password_hash = await bcrypt.hash(dto.password, SALT_ROUNDS);
    const user = this.userRepo.create({
      name: dto.name, email: dto.email,
      password_hash, role: dto.role as unknown as UserRole,
    });
    const saved = await this.userRepo.save(user);
    const { password_hash: _, ...result } = saved;
    return result;
  }

  async findAll(role?: Role) {
    const where = role ? { role: role as unknown as UserRole } : {};
    const users = await this.userRepo.find({
      where,
      order: { created_at: 'DESC' },
      select: ['id', 'name', 'email', 'role', 'created_at'],
    });
    return users;
  }

  async findOne(id: string) {
    const user = await this.userRepo.findOne({
      where: { id },
      select: ['id', 'name', 'email', 'role', 'created_at'],
    });
    if (!user) throw new NotFoundException(`Usuario con id ${id} no encontrado`);
    return user;
  }

  async update(id: string, dto: UpdateUserDto) {
    await this.findOne(id);

    if (dto.email) {
      const existing = await this.userRepo.findOne({ where: { email: dto.email } });
      if (existing && existing.id !== id)
        throw new ConflictException(`El email ${dto.email} ya está en uso`);
    }

    const updateData: Partial<User> = {};
    if (dto.name)     updateData.name  = dto.name;
    if (dto.email)    updateData.email = dto.email;
    if (dto.role)     updateData.role  = dto.role as unknown as UserRole;
    if (dto.password) updateData.password_hash = await bcrypt.hash(dto.password, SALT_ROUNDS);

    await this.userRepo.update(id, updateData);
    return this.findOne(id);
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.userRepo.delete(id);
    return { message: `Usuario con id ${id} eliminado correctamente` };
  }
}
