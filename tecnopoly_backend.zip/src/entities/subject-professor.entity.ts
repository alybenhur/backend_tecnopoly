import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, ManyToOne, JoinColumn, Unique,
} from 'typeorm';
import { User }    from './user.entity';
import { Subject } from './subject.entity';

@Entity('subject_professors')
@Unique(['subject_id', 'professor_id'])
export class SubjectProfessor {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'subject_id' })
  subject_id: string;

  @Column({ name: 'professor_id' })
  professor_id: string;

  @CreateDateColumn({ name: 'assigned_at' })
  assigned_at: Date;

  // Relaciones
  @ManyToOne(() => Subject, s => s.subject_professors, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'subject_id' })
  subject: Subject;

  @ManyToOne(() => User, u => u.assignments, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'professor_id' })
  professor: User;
}
