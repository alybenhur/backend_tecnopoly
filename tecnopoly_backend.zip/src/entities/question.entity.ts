import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, ManyToOne, OneToMany, JoinColumn,
} from 'typeorm';
import { User }         from './user.entity';
import { Subject }      from './subject.entity';
import { AnswerOption } from './answer-option.entity';

export enum QuestionLevelEnum {
  BASICO   = 'basico',
  MEDIO    = 'medio',
  AVANZADO = 'avanzado',
}

@Entity('questions')
export class Question {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'subject_id' })
  subject_id: string;

  @Column({ name: 'created_by', nullable: true })
  created_by: string;

  @Column({ type: 'text', name: 'question_text' })
  question_text: string;

  @Column({ name: 'correct_answer_index' })
  correct_answer_index: number;

  @Column({ name: 'reward_credits', default: 100 })
  reward_credits: number;

  @Column({ name: 'penalty_credits', default: 50 })
  penalty_credits: number;

  @Column({ type: 'text', name: 'correct_explanation' })
  correct_explanation: string;

  @Column({ type: 'text', name: 'incorrect_explanation' })
  incorrect_explanation: string;

  @Column({ type: 'enum', enum: QuestionLevelEnum })
  level: QuestionLevelEnum;

  @Column({ type: 'text', name: 'image_url', nullable: true })
  image_url: string;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  // Relaciones
  @ManyToOne(() => Subject, s => s.questions, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'subject_id' })
  subject: Subject;

  @ManyToOne(() => User, u => u.questions, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'created_by' })
  createdBy: User;

  @OneToMany(() => AnswerOption, ao => ao.question, { cascade: true, eager: true })
  answer_options: AnswerOption[];
}
