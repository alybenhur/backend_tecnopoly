import {
  Entity, PrimaryGeneratedColumn, Column,
  ManyToOne, JoinColumn, Unique,
} from 'typeorm';
import { Question } from './question.entity';

@Entity('answer_options')
@Unique(['question_id', 'order_index'])
export class AnswerOption {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'question_id' })
  question_id: string;

  @Column({ type: 'text', name: 'option_text' })
  option_text: string;

  @Column({ name: 'order_index' })
  order_index: number;

  // Relación
  @ManyToOne(() => Question, q => q.answer_options, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'question_id' })
  question: Question;
}
