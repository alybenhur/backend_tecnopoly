import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, ManyToOne, OneToMany, JoinColumn,
} from 'typeorm';
import { User }             from './user.entity';
import { Grade }            from './grade.entity';
import { SubjectProfessor } from './subject-professor.entity';
import { Question }         from './question.entity';

@Entity('subjects')
export class Subject {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true, length: 100 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ name: 'created_by', nullable: true })
  created_by: string;

  @Column({ name: 'grade_id', nullable: true })
  grade_id: string;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  // Relaciones
  @ManyToOne(() => User,  u => u.subjects_created, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'created_by' })
  createdBy: User;

  @ManyToOne(() => Grade, g => g.subjects, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'grade_id' })
  grade: Grade;

  @OneToMany(() => SubjectProfessor, sp => sp.subject)
  subject_professors: SubjectProfessor[];

  @OneToMany(() => Question, q => q.subject)
  questions: Question[];
}
