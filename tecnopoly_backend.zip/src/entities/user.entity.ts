import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, OneToMany,
} from 'typeorm';
import { SubjectProfessor } from './subject-professor.entity';
import { Subject }          from './subject.entity';
import { Question }         from './question.entity';
import { Grade }            from './grade.entity';

export enum UserRole {
  ADMIN   = 'admin',
  PROFESOR = 'profesor',
}

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 100 })
  name: string;

  @Column({ unique: true, length: 150 })
  email: string;

  @Column({ name: 'password_hash' })
  password_hash: string;

  @Column({ type: 'enum', enum: UserRole })
  role: UserRole;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  // Relaciones
  @OneToMany(() => Subject,          s  => s.createdBy)  subjects_created: Subject[];
  @OneToMany(() => Grade,            g  => g.createdBy)  grades_created: Grade[];
  @OneToMany(() => SubjectProfessor, sp => sp.professor)  assignments: SubjectProfessor[];
  @OneToMany(() => Question,         q  => q.createdBy)  questions: Question[];
}
